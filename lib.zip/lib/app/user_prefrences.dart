class UserPreferences {
  String? userToken ;
  String? email;
  String? password;
  String? sourceCode;
 // 1 for light theme, 0 for dark theme
}