// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'add_to_wish_list_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AddToWishListResponse _$AddToWishListResponseFromJson(
        Map<String, dynamic> json) =>
    AddToWishListResponse(
      json['success'] as bool?,
      json['message'] as String?,
    );

Map<String, dynamic> _$AddToWishListResponseToJson(
        AddToWishListResponse instance) =>
    <String, dynamic>{
      'success': instance.success,
      'message': instance.message,
    };
