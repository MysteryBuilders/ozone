// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'generate_invoice_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GenrateInvoiceResponse _$GenrateInvoiceResponseFromJson(
        Map<String, dynamic> json) =>
    GenrateInvoiceResponse(
      items: json['items'] as List<dynamic>,
    );

Map<String, dynamic> _$GenrateInvoiceResponseToJson(
        GenrateInvoiceResponse instance) =>
    <String, dynamic>{
      'items': instance.items,
    };
