// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'new_login_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

NewLoginResponse _$NewLoginResponseFromJson(Map<String, dynamic> json) =>
    NewLoginResponse(
      json['token'] as String?,
    );

Map<String, dynamic> _$NewLoginResponseToJson(NewLoginResponse instance) =>
    <String, dynamic>{
      'token': instance.token,
    };
