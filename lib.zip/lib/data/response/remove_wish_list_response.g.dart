// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'remove_wish_list_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

RemoveWishListResponse _$RemoveWishListResponseFromJson(
        Map<String, dynamic> json) =>
    RemoveWishListResponse(
      json['success'] as bool?,
      json['message'] as String?,
    );

Map<String, dynamic> _$RemoveWishListResponseToJson(
        RemoveWishListResponse instance) =>
    <String, dynamic>{
      'success': instance.success,
      'message': instance.message,
    };
