class AddItemToWishListModel{
  bool success;
  String message;
  AddItemToWishListModel(this.success,this.message);

}