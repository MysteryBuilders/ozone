class ErrorModel{
  final String message;

  ErrorModel(this.message);
}