class GenerateInvoiceModel {
  List<dynamic>? result;

  GenerateInvoiceModel(this.result);
}