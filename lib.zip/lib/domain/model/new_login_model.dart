class NewLoginModel{
  String? token;
  NewLoginModel(this.token);
}