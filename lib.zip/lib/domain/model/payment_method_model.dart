class PaymentMethodModel{
  String? code;

  String? title;
  PaymentMethodModel(this.code,this.title);
}