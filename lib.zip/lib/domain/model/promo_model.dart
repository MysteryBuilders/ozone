class PromoModel{
  String whatsAppNumber;
  String promoText;
  PromoModel(this.whatsAppNumber,this.promoText);
}