class RegisterModel{

  int? id;

  int? group_id;

  String? created_at;

  String? updated_at;

  String? created_in;

  String? email;

  String? firstname;

  String? lastname;

  int? store_id;

  int? website_id;

  RegisterModel(this.id,this.group_id,this.created_at,this.updated_at,
      this.created_in,this.email,this.firstname,this.lastname,this.store_id,this.website_id);

}