class RemoveWishListModel{
  bool success;
  String message;
  RemoveWishListModel(this.success,this.message);

}