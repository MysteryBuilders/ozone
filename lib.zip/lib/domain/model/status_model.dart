class StatusModel{
  String statusKey;
  String statusString;
  bool isChecked;
  StatusModel(this.statusKey,this.statusString,this.isChecked);
}