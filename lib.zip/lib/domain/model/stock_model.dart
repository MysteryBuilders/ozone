class StockModel{

  int? itemId;

  int? productId;

  int? stockId;

  bool? isInStock;

  int? minSaleQty;

  int? qty;

  StockModel(this.itemId,this.productId,this.stockId,this.isInStock,
      this.minSaleQty,this.qty);
}