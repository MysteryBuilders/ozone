class StoreLocatorModel{
  String? storeCode;

  int? webSiteId;
  String? sourceCode;
  StoreLocatorModel(this.storeCode,this.webSiteId,this.sourceCode);
}