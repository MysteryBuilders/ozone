class UserInfoModel{

  int? id;

  String? email;

  String? firstname;

  String? lastname;

  int? storeId;

  int? websiteId;
  UserInfoModel(this.id,this.email,this.firstname,this.lastname,this.storeId,this.websiteId);
}