import 'package:flutter/material.dart';

class LocalizationState {
  final Locale locale;

  LocalizationState(this.locale);
}