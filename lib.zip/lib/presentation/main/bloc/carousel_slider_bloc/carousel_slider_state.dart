class CarouselSLiderState {
  final int activeIndex;

  CarouselSLiderState(this.activeIndex);
}