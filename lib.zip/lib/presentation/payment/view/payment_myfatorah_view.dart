import 'package:flutter/material.dart';


class PaymentMyfatorahView extends StatefulWidget {
  const PaymentMyfatorahView({super.key});

  @override
  State<PaymentMyfatorahView> createState() => _PaymentMyfatorahViewState();
}

class _PaymentMyfatorahViewState extends State<PaymentMyfatorahView> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
