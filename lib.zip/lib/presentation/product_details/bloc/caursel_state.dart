class CarouselState {
  final int currentIndex;
  CarouselState(this.currentIndex);
}
