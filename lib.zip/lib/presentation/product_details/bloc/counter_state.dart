class CounterState {
  final int count;
  CounterState(this.count);
}
