import 'package:flutter/material.dart';

class PriceRangeState {
  final RangeValues range;

  PriceRangeState(this.range);
}
