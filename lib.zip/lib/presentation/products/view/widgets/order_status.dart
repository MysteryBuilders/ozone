enum OrderStatus{
  pending,
  processing,
  complete,
  closed,
  canceled,
  holded,
  payment_review
}