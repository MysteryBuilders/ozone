abstract class GifEvent {}

class GifStarted extends GifEvent {}

class GifCompleted extends GifEvent {}