abstract class GifState {}

class GifInitial extends GifState {}

class GifPlaying extends GifState {}

class GifFinished extends GifState {}